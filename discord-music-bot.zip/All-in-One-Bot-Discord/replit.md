# Overview

This is a Discord bot built with Discord.js v14 that provides comprehensive functionality including music playback, moderation tools, giveaway management, and server configuration features. The bot uses a command-based architecture with support for slash commands and traditional message-based prefix commands.

## Recent Changes (November 2025)

### Complete Environment Reinstall (November 8, 2025)
- **Node.js 22.17.0**: Fresh install of latest LTS version (upgraded from older version)
- **npm 10.9.2**: Latest package manager version
- **FFmpeg-full 4.4.1**: Complete ffmpeg installation with all codecs for audio processing
- **All packages updated**: Reinstalled all npm dependencies with latest compatible versions
- **youtubei.js 16.0.1**: Updated to latest version for YouTube streaming
- **discord.js 14.17.3**: Updated to latest stable version
- **Fixed interaction errors**: Moved deferReply to top of /play command to prevent timeout errors
- **Created .gitignore**: Added comprehensive Node.js gitignore file

### Previous Changes
- **Upgraded to Discord.js v14**: Updated from v12 to v14 with modern slash command support
- **Added Moderation Commands**: Implemented warn, mute, unmute, and level commands in `index.js`
- **Fixed Purge Command**: Resolved interaction acknowledgment issue by properly deferring replies
- **JSON Database**: Simplified data persistence using file-based JSON storage for warnings, levels, and XP
- **Enhanced Validation**: Added input validation for mute duration (1-40320 minutes / 28 days max)
- **Improved Error Handling**: Added try-catch for database file corruption recovery
- **Upgraded DisTube to v5**: Migrated music system to DisTube v5.0.7 with @distube/youtube plugin
- **Added /play Command**: Implemented slash command for YouTube music playback (links or search terms)

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
- **Discord.js v14**: Core Discord API wrapper for bot functionality
- **Event-driven architecture**: Separate event handlers for different Discord events (message, voiceStateUpdate, guildMemberAdd, etc.)
- **Command handler system**: Modular command structure organized by category in the `/commands` folder

## Music System
- **DisTube v5**: Primary music playback library (v5.0.7) for handling YouTube streaming with plugin architecture
- **@distube/youtube**: Official YouTube plugin using youtubei.js for video/audio extraction (no external binaries)
- **Voice integration**: Uses @discordjs/voice and @discordjs/opus for voice channel connectivity
- **FFmpeg**: System-level audio processing dependency installed via Nix for encoding/decoding
- **/play Command**: Slash command accepting YouTube links or search terms with automatic queue management
- **Event handlers**: playSong, addSong, and error events with embed-based notifications

## Data Persistence
- **File-based JSON storage**: 
  - `database.json`: Primary storage for warnings, XP, and leveling data (active in index.js)
    - Structure: `{ warnings: {}, levels: {}, xp: {} }`
    - Keys format: `{guild_id}_{user_id}`
    - Auto-recovery on file corruption
  - `giveaways.json`: Giveaway state management
  - Configuration files in `/config` directory
- **MongoDB integration**: Mongoose schemas for persistent features (antiraid, antilink, antiwords, autorole, welcome messages)
- **Note**: Quick.db and better-sqlite3 are installed but not actively used due to Node.js version compatibility issues

## Command Categories
1. **Music (🎶)**: Play, pause, skip, queue, volume, filters, search, autoplay
2. **Moderation (🚫)**: 
   - **ban**: Ban members from server (requires BanMembers permission)
   - **kick**: Kick members from server (requires KickMembers permission)
   - **warn**: Issue warnings to users with tracking (requires ModerateMembers permission)
   - **mute**: Apply timeout to users (1-40320 minutes, requires ModerateMembers permission)
   - **unmute**: Remove timeout from users (requires ModerateMembers permission)
   - **purge**: Bulk delete messages (2-100, requires ManageMessages permission)
3. **Configuration (⚙️)**: Antilink, antiraid, antiwords, autorole, welcome system, join-to-create voice, backup/restore
4. **Giveaways (🎁)**: Create, start, end, reroll, list giveaways using discord-giveaways library
5. **Information (🔰)**: 
   - **level**: Display user level and XP progress (optional user parameter)
   - Avatar, botinfo, serverinfo, userinfo, roleinfo, channelinfo, help, ping, uptime
6. **Owner**: Server management commands restricted to bot owner

## Security & Moderation
- **Permission checks**: Commands verify user and bot permissions before execution
- **Input validation**: Mute duration limited to Discord's 28-day timeout cap
- **Moderation tracking**: Warning system with timestamp and moderator attribution
- **Anti-spam systems**: Antilink, antiword, and antiraid protection with MongoDB persistence
- **Verification system**: Channel-based user verification with role assignment using discord-buttons
- **Deferred interactions**: Proper handling of long-running operations (e.g., bulk message deletion)

## Special Features
- **Join-to-create voice channels**: Dynamic voice channel creation when users join specific channel
- **AFK system**: Tracks user AFK status with timestamps
- **Auto-role**: Automatic role assignment on member join
- **Welcome/Leave messages**: Customizable welcome messages with placeholders
- **Server backup**: Full server backup and restore functionality using discord-backup
- **Chatbot integration**: smartestchatbot library for automated responses

## Configuration Management
- **Environment variables**: `.env` file for sensitive data (bot token, MongoDB URL)
- **JSON configs**: 
  - `config.json`: Bot settings, prefix, owner IDs, audio filters
  - `embed.json`: Embed color schemes and footer text
  - `emojis.json`: Custom emoji mappings for bot responses
  - `settings.json`: Feature toggles

## Error Handling
- Try-catch blocks in command execution
- Ephemeral error messages with auto-deletion timeouts
- Database fallback creation on read errors

# External Dependencies

## Core Dependencies
- **Node.js v22.17.0**: Latest LTS runtime environment
- **npm v10.9.2**: Package manager
- **Discord.js v14.17.3**: Main Discord API library
- **dotenv v16.4.7**: Environment variable management

## Music & Audio
- **DisTube v5.0.7**: Music queue and playback management with plugin system
- **@discordjs/voice v0.17.0**: Voice connection handling
- **youtubei.js v16.0.1**: YouTube API wrapper for video/audio extraction
- **@distube/ytdl-core v4.14.4**: YouTube downloader core
- **FFmpeg-full v4.4.1**: Complete system dependency for audio processing with all codecs (installed via Nix)
- **spotify-url-info v2.2.3**: Spotify metadata extraction
- **play-dl v1.9.7**: Additional YouTube/SoundCloud support
- **opusscript v0.1.1**: Opus audio codec
- **sodium-native v4.3.1**: Encryption library for voice

## Database
- **Mongoose v8.9.6**: MongoDB ODM for persistent storage (updated to latest version)

## Utilities
- **discord-giveaways v6.0.1**: Giveaway management system (updated)
- **discord-backup v2.5.0**: Server backup functionality
- **discord-buttons v4.0.0**: Button interaction handling (legacy)
- **discord-reply v0.1.2**: Reply functionality
- **moment v2.30.1**: Date/time formatting (updated)
- **ms v2.1.3**: Time string parsing (updated)
- **Express v4.21.2**: Web server (updated to latest stable version)

## Additional Libraries
- **smartestchatbot v2.0.0**: AI chatbot integration
- **ascii-table 0.0.9**: Console table formatting
- **colors v1.4.0**: Console color output
- **cpu-stat v2.0.1**: System resource monitoring
- **enmap v5.8.6**: Enhanced Map data structure

## APIs & Services
- **MongoDB**: External database for persistent data storage (connection URL in env)
- **YouTube**: Music source via ytdl-core
- **Spotify**: Music metadata via spotify-url-info