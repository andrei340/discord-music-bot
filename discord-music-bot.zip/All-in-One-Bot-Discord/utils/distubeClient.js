const client = require("../index");
const { DisTube } = require("distube");
const { YtDlpPlugin } = require("@distube/yt-dlp");
const { SpotifyPlugin } = require("@distube/spotify");
const { SoundCloudPlugin } = require("@distube/soundcloud");
const config = require('../config/config.json')

let distube = new DisTube(client, {
  searchSongs: 0,
  emitNewSongOnly: false,
  leaveOnEmpty: false,
  leaveOnFinish: false,
  leaveOnStop: false,
  customFilters : config.customFilters,
  plugins: [
    new YtDlpPlugin(),
    new SpotifyPlugin(),
    new SoundCloudPlugin()
  ]
});


module.exports = distube;
