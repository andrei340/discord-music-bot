const { Collection } =  require('discord.js');

const afk = new Collection();

module.exports = { afk };